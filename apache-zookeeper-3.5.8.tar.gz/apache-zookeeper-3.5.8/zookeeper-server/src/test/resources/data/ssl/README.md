SSL test data
===================

testKeyStore.jks
---
Testing keystore, password is "testpass".

testTrustStore.jks
---
Testing truststore, password is "testpass".
